INSERT OVERWRITE ${catalog}.${schema}.dataset_config VALUES
('retail.orders','Retail Orders','bigquery','${gcp_project}.retail_prod.orders',NULL,NULL,'order_id',NULL,'Retail Ops',true),
('retail.customers','Retail Customers','gcs_csv','gs://${gcs_bucket}/customers.csv','csv','{"header":"true","inferSchema":"true"}','customer_id',NULL,'CRM Team',true),
('retail.products','Retail Products','gcs_delta','gs://${gcs_bucket}/delta/products','delta',NULL,'product_id',NULL,'Catalog Team',true);

INSERT OVERWRITE ${catalog}.${schema}.rule_config VALUES
('R001','retail.orders','completeness','order_id',NULL,'CRITICAL',0,'FAIL_PIPELINE',true),
('R002','retail.orders','uniqueness','order_id',NULL,'CRITICAL',0,'FAIL_PIPELINE',true),
('R003','retail.orders','referential_integrity','customer_id','retail.customers|customer_id','WARN',5,'ALERT_ONLY',true),
('R004','retail.orders','validity_range','order_total','0|100000','CRITICAL',0,'QUARANTINE',true),
('R005','retail.orders','timeliness','updated_at','24','WARN',0,'ALERT_ONLY',true),
('R006','retail.orders','schema_check','order_total','NUMERIC','WARN',0,'ALERT_ONLY',true),
('R007','retail.customers','completeness','customer_id',NULL,'CRITICAL',0,'FAIL_PIPELINE',true),
('R008','retail.customers','uniqueness','customer_id',NULL,'CRITICAL',0,'FAIL_PIPELINE',true),
('R009','retail.customers','validity_pattern','email','^[^@\s]+@[^@\s]+\.[^@\s]+$','WARN',0,'ALERT_ONLY',true),
('R010','retail.customers','validity_list','country','IN|US|UK|CA|DE','WARN',10,'ALERT_ONLY',true),
('R011','retail.products','completeness','product_name',NULL,'WARN',0,'ALERT_ONLY',true),
('R012','retail.products','validity_range','unit_price','0|50000','CRITICAL',0,'QUARANTINE',true),
('R013','retail.products','uniqueness','product_id',NULL,'CRITICAL',0,'FAIL_PIPELINE',true),
('R014','retail.orders','reconciliation',NULL,'retail.orders_snapshot|0','WARN',0,'ALERT_ONLY',false);
