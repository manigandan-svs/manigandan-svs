import json

def append_rows(spark, table_name, rows):
    if rows:
        spark.createDataFrame(rows).write.mode("append").saveAsTable(table_name)

def append_quarantine(df, table_name, run_id, dataset_id, rule_id, limit=1000):
    from pyspark.sql import functions as F
    (df.limit(limit)
       .select(F.lit(run_id).alias("run_id"),F.lit(dataset_id).alias("dataset_id"),
               F.lit(rule_id).alias("rule_id"),F.to_json(F.struct("*")).alias("source_record_json"),
               F.current_timestamp().alias("quarantined_at"))
       .write.mode("append").saveAsTable(table_name))
