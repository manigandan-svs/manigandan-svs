import argparse
from dq_framework.engine import DQEngine

def parse_args():
    p=argparse.ArgumentParser(); p.add_argument("--catalog",default="main"); p.add_argument("--schema",default="dq_meta"); return p.parse_args()

def main():
    from pyspark.sql import SparkSession
    args=parse_args(); spark=SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()
    runs,results=DQEngine(spark,args.catalog,args.schema).run_all()
    print({"datasets":len(runs),"rules":len(results)})

if __name__=="__main__": main()
