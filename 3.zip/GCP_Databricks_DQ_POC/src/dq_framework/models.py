from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class DatasetConfig:
    dataset_id: str
    dataset_name: str
    source_type: str
    location: str
    file_format: Optional[str] = None
    options_json: Optional[str] = None
    primary_key_cols: Optional[str] = None
    watermark_column: Optional[str] = None
    data_owner: Optional[str] = None

@dataclass(frozen=True)
class RuleConfig:
    rule_id: str
    dataset_id: str
    rule_type: str
    column_name: Optional[str]
    rule_expression: Optional[str]
    severity: str
    threshold_pct: float
    action: str
