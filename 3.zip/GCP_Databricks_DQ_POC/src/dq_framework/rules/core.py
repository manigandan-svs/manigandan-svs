import re
from pyspark.sql import functions as F

def _require_column(df, name):
    if name not in df.columns:
        raise ValueError(f"Column not found: {name}")

def completeness(df, rule, context):
    _require_column(df, rule.column_name)
    c=F.col(rule.column_name)
    return c.isNull() | (F.trim(c.cast("string")) == "")

def validity_range(df, rule, context):
    _require_column(df, rule.column_name)
    lo,hi=[float(x.strip()) for x in rule.rule_expression.split("|")]
    c=F.col(rule.column_name)
    return c.isNotNull() & ((c < lo) | (c > hi))

def validity_pattern(df, rule, context):
    _require_column(df, rule.column_name)
    c=F.col(rule.column_name)
    return c.isNotNull() & (~c.cast("string").rlike(rule.rule_expression))

def validity_list(df, rule, context):
    _require_column(df, rule.column_name)
    values=[x.strip() for x in rule.rule_expression.split("|")]
    c=F.col(rule.column_name)
    return c.isNotNull() & (~c.cast("string").isin(values))

def timeliness(df, rule, context):
    _require_column(df, rule.column_name)
    hours=float(rule.rule_expression)
    c=F.to_timestamp(F.col(rule.column_name))
    return c.isNull() | ((F.unix_timestamp(F.current_timestamp())-F.unix_timestamp(c))/3600 > hours)
