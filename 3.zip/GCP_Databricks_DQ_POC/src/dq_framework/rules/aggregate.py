from pyspark.sql import functions as F

def uniqueness_counts(df, rule, context):
    c=rule.column_name
    if c not in df.columns: raise ValueError(f"Column not found: {c}")
    total=df.count()
    distinct=df.select(c).distinct().count()
    return total, total-distinct, None

def referential_integrity_counts(df, rule, context):
    ref_dataset,ref_column=[x.strip() for x in rule.rule_expression.split("|")]
    ref_df=context["datasets"][ref_dataset]
    c=rule.column_name
    failed=(df.filter(F.col(c).isNotNull())
              .join(ref_df.select(F.col(ref_column).alias(c)).distinct(), c, "left_anti")
              .count())
    return df.count(), failed, None

def reconciliation_counts(df, rule, context):
    # Expression: reference_dataset_id|absolute_tolerance
    ref_dataset,tol=[x.strip() for x in rule.rule_expression.split("|")]
    source_count=df.count(); reference_count=context["datasets"][ref_dataset].count()
    failed=0 if abs(source_count-reference_count) <= int(tol) else 1
    return 1, failed, {"source_count":source_count,"reference_count":reference_count}

def schema_check_counts(df, rule, context):
    expected=rule.rule_expression.upper()
    actual=dict(df.dtypes).get(rule.column_name)
    aliases={"STRING":{"string"},"NUMERIC":{"decimal","double","float","bigint","int"},"TIMESTAMP":{"timestamp"},"DATE":{"date"}}
    ok=actual is not None and any(actual.startswith(x) for x in aliases.get(expected,{expected.lower()}))
    return 1, 0 if ok else 1, {"actual_type":actual,"expected_type":expected}
