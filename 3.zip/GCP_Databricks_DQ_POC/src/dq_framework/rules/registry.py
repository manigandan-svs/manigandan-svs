from .core import completeness, validity_range, validity_pattern, validity_list, timeliness
from .aggregate import uniqueness_counts, referential_integrity_counts, reconciliation_counts, schema_check_counts

ROW_RULES={
 "completeness": completeness,
 "validity_range": validity_range,
 "validity_pattern": validity_pattern,
 "validity_list": validity_list,
 "timeliness": timeliness,
}
AGGREGATE_RULES={
 "uniqueness": uniqueness_counts,
 "referential_integrity": referential_integrity_counts,
 "reconciliation": reconciliation_counts,
 "schema_check": schema_check_counts,
}
