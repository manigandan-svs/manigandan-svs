import datetime as dt, json, uuid
from pyspark.sql import functions as F
from .models import DatasetConfig, RuleConfig
from .readers.registry import get_reader
from .rules.registry import ROW_RULES, AGGREGATE_RULES
from .audit import append_rows, append_quarantine

class DQEngine:
    def __init__(self,spark,catalog="main",schema="dq_meta"):
        self.spark=spark; self.ns=f"{catalog}.{schema}"
    def _configs(self):
        datasets=[DatasetConfig(**r.asDict()) for r in self.spark.table(f"{self.ns}.dataset_config").filter("is_active=true").drop("is_active").collect()]
        rules=[RuleConfig(**r.asDict()) for r in self.spark.table(f"{self.ns}.rule_config").filter("is_active=true").drop("is_active").collect()]
        return datasets,rules
    def run_all(self):
        datasets,rules=self._configs()
        frames={d.dataset_id:get_reader(d.source_type).read(self.spark,d) for d in datasets}
        run_rows=[]; result_rows=[]
        for d in datasets:
            run_id=str(uuid.uuid4()); start=dt.datetime.now(dt.timezone.utc); status="PASS"; error=None; evaluated=0
            df=frames[d.dataset_id]
            try:
                for rule in [r for r in rules if r.dataset_id==d.dataset_id]:
                    evaluated+=1; sample=None; details=None
                    if rule.rule_type in ROW_RULES:
                        failed_df=df.filter(ROW_RULES[rule.rule_type](df,rule,{"datasets":frames}))
                        total=df.count(); failed=failed_df.count(); sample=failed_df
                    elif rule.rule_type in AGGREGATE_RULES:
                        total,failed,details=AGGREGATE_RULES[rule.rule_type](df,rule,{"datasets":frames})
                    else: raise ValueError(f"Unsupported rule_type: {rule.rule_type}")
                    pct=round(failed*100.0/total,2) if total else 0.0
                    rs="PASS" if pct <= float(rule.threshold_pct or 0) else "FAIL"
                    if rs=="FAIL":
                        status="FAIL" if rule.severity=="CRITICAL" else ("WARN" if status=="PASS" else status)
                        if rule.action=="QUARANTINE" and sample is not None:
                            append_quarantine(sample,f"{self.ns}.quarantine_log",run_id,d.dataset_id,rule.rule_id)
                    result_rows.append({"run_id":run_id,"dataset_id":d.dataset_id,"rule_id":rule.rule_id,"rule_type":rule.rule_type,"column_name":rule.column_name or "","severity":rule.severity,"records_checked":int(total),"records_failed":int(failed),"failure_pct":float(pct),"threshold_pct":float(rule.threshold_pct or 0),"status":rs,"details_json":json.dumps(details or {}),"run_ts":dt.datetime.now(dt.timezone.utc)})
            except Exception as exc:
                status="ERROR"; error=str(exc)[:4000]
            run_rows.append({"run_id":run_id,"dataset_id":d.dataset_id,"source_type":d.source_type,"start_time":start,"end_time":dt.datetime.now(dt.timezone.utc),"records_read":df.count(),"rules_evaluated":evaluated,"status":status,"error_details":error})
        append_rows(self.spark,f"{self.ns}.result_log",result_rows); append_rows(self.spark,f"{self.ns}.run_log",run_rows)
        return run_rows,result_rows
