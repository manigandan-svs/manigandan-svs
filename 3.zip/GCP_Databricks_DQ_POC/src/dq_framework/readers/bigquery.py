from .base import SourceReader

class BigQueryReader(SourceReader):
    def read(self, spark, config):
        # Requires the Databricks-supported Spark BigQuery connector/runtime setup.
        return (spark.read.format("bigquery")
                .option("table", config.location)
                .load())
