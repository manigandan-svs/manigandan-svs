from abc import ABC, abstractmethod

class SourceReader(ABC):
    @abstractmethod
    def read(self, spark, config):
        """Return a Spark DataFrame for one configured dataset."""
