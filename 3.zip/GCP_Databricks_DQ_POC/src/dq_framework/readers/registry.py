from .bigquery import BigQueryReader
from .gcs import GCSReader

READERS = {
    "bigquery": BigQueryReader(),
    "gcs_csv": GCSReader(),
    "gcs_parquet": GCSReader(),
    "gcs_delta": GCSReader(),
}

def get_reader(source_type):
    reader = READERS.get(source_type)
    if reader is None:
        raise ValueError(f"Unsupported source_type: {source_type}")
    return reader
