import json
from .base import SourceReader

class GCSReader(SourceReader):
    def read(self, spark, config):
        fmt = config.file_format or "parquet"
        options = json.loads(config.options_json or "{}")
        reader = spark.read.format(fmt)
        for key, value in options.items():
            reader = reader.option(key, value)
        return reader.load(config.location)
