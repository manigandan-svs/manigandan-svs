from pathlib import Path
import ast
R=Path(__file__).parents[1]
def test_python_parses():
    for p in (R/'src').rglob('*.py'): ast.parse(p.read_text())
def test_multi_source_registry():
    s=(R/'src/dq_framework/readers/registry.py').read_text()
    assert 'bigquery' in s and 'gcs_csv' in s and 'gcs_delta' in s
def test_rule_coverage():
    s=(R/'src/dq_framework/rules/registry.py').read_text()
    for name in ['completeness','uniqueness','validity_range','validity_pattern','validity_list','referential_integrity','timeliness','schema_check','reconciliation']:
        assert name in s
