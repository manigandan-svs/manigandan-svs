# GCP + Databricks Metadata-Driven DQ POC

This package implements the design previously shared: Databricks on Google Cloud provides the generic PySpark engine; BigQuery and GCS are demonstrated source types; Delta tables hold configuration, audit, and quarantine data.

## Source types
- BigQuery native table: retail.orders
- GCS CSV: retail.customers
- GCS Delta: retail.products

## Implemented checks
Completeness, uniqueness, numeric range, regex pattern, allowed list, referential integrity, timeliness, schema check, and count reconciliation.

## Routine onboarding
Add dataset_config and rule_config rows for supported readers and rules. No dataset-specific engine code is required. New technologies are introduced through SourceReader and rule-registry plug-ins.

## POC execution
1. Configure Databricks on Google Cloud access to BigQuery and GCS according to client security standards.
2. Create metadata and audit Delta tables with sql/01_create_tables.sql.
3. Upload sample data and adjust placeholders in sql/02_seed_metadata.sql.
4. Deploy with Databricks Asset Bundles.
5. Run the metadata-driven-dq-poc job.
6. Query run_log, result_log, and quarantine_log.

## Boundaries
The package is statically validated but not executed against a live client GCP or Databricks workspace. BigQuery connector availability, identities, catalog names, storage permissions, and production sizing must be validated in the target environment.
